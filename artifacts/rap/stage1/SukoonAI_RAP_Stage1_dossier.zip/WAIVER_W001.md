﻿# RAP Waiver W-001 — Assist (cited) drill

**Date (UTC):** 10/14/2025 08:41:14.ToUniversalTime().ToString("s")Z
**Scope:** Stage-1 / Step-1 / Assist (cited) drill
**Status:** Drill failing: evidence_shape_ok==False (schema shortfall)
**Risk:** Governed-RAG proof incomplete in audit; demo may omit live citations
**Mitigation (temporary):** Proceed to ICP for demo; keep crisis/abstain zero-token gates; restrict citations in demo if needed
**Exit criteria:** Assist (cited) passes with 1–3 items each {id,title,snippet}; update drills/summary.json (all_pass=true)
**Expiry:** Valid only until HSA demo; must be cleared before GA
